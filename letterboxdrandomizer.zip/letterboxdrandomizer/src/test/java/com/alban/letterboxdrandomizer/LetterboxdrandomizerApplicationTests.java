package com.alban.letterboxdrandomizer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LetterboxdrandomizerApplicationTests {

	@Test
	void contextLoads() {
	}

}
